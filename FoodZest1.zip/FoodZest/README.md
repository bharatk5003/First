# FoodZest

Food Ordering app for Internshala Android Development Training

Url and token were provided by internshala itself.

NOTE:- **Replace your token in "Android->app->res->values->strings"**

**Refer to Screenshots folder for UI**
